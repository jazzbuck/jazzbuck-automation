---
id: {{date}}
aliases: ["to-do: {{subject}}"]
---
#todo

# {{subject}}

{{text}}
