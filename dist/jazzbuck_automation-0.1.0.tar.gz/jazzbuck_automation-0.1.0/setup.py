# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['jazzbuck_automation', 'jazzbuck_automation.tests']

package_data = \
{'': ['*'], 'jazzbuck_automation': ['templates/*']}

install_requires = \
['orjson>=3.8.5,<4.0.0', 'pyyaml>=6.0,<7.0', 'requests>=2.28.2,<3.0.0']

setup_kwargs = {
    'name': 'jazzbuck-automation',
    'version': '0.1.0',
    'description': 'Scripts to run on a web server to help me in my life.',
    'long_description': '',
    'author': 'jazzbuck',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
